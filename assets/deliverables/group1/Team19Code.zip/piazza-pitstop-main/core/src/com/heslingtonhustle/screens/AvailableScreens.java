package com.heslingtonhustle.screens;

public enum AvailableScreens {
    MenuScreen,
    PlayScreen
}
