package com.heslingtonhustle.state;

public interface DialogueCallback {
    void onSelected(int selectedOption);
}
