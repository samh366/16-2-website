package com.heslingtonhustle.state;

public enum Facing {
    UP,
    DOWN,
    LEFT,
    RIGHT
}
