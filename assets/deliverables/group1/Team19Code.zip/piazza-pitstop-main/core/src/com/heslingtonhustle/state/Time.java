package com.heslingtonhustle.state;

public enum Time {
    MORNING,
    AFTERNOON,
    EVENING,
    NIGHT
}
