<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="forest_" tilewidth="16" tileheight="16" tilecount="198" columns="22">
 <image source="../Graphics/taiga_.png" width="352" height="144"/>
</tileset>
