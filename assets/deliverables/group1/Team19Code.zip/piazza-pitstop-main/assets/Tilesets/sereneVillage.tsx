<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="Serene_Village_16x16" tilewidth="16" tileheight="16" tilecount="855" columns="19">
 <image source="../Graphics/sereneVillage.png" trans="ff00ff" width="304" height="720"/>
</tileset>
