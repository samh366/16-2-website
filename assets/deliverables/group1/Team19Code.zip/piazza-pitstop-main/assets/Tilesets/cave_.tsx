<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="cave_" tilewidth="16" tileheight="16" tilecount="264" columns="22">
 <image source="../Graphics/cave_.png" width="352" height="192"/>
</tileset>
